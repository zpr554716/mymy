RAICOM2026 final Webots package
Generated 2026-05-01

Worlds:
- worlds/raicom2026_arena.wbt
- worlds/raicom_workpieces_flat_test.wbt
- worlds/raicom2026_arena_compensated_circle.wbt

Files:
- meshes/converted/raicom_placement_tray_compensated.obj
- meshes/converted/raicom_placement_tray_holed.obj
- meshes/converted/wuliaoxiaohe.stl
- protos/icons/Raicom2026Arena.png
- protos/icons/RaicomConvertedPickBox.png
- protos/icons/RaicomConvertedPlacementTray.png
- protos/icons/RaicomWorkpieceCircle.png
- protos/icons/RaicomWorkpieceClover.png
- protos/icons/RaicomWorkpieceParallelogram.png
- protos/icons/RaicomWorkpiecePentagon.png
- protos/icons/RaicomWorkpiecePlus.png
- protos/icons/RaicomWorkpieceRectangle.png
- protos/icons/RaicomWorkpieceSquare.png
- protos/icons/RaicomWorkpieceStar.png
- protos/icons/RaicomWorkpieceTriangle.png
- protos/Raicom2026Arena.proto
- protos/Raicom2026ArenaCompensated.proto
- protos/RaicomConvertedPickBox.proto
- protos/RaicomConvertedPlacementTray.proto
- protos/RaicomConvertedPlacementTrayCompensated.proto
- protos/RaicomWorkpieceCircle.proto
- protos/RaicomWorkpieceCircleCompensated.proto
- protos/RaicomWorkpieceClover.proto
- protos/RaicomWorkpieceParallelogram.proto
- protos/RaicomWorkpiecePentagon.proto
- protos/RaicomWorkpiecePlus.proto
- protos/RaicomWorkpieceRectangle.proto
- protos/RaicomWorkpieceSquare.proto
- protos/RaicomWorkpieceStar.proto
- protos/RaicomWorkpieceTriangle.proto
- worlds/raicom2026_arena.wbt
- worlds/raicom2026_arena_compensated_circle.wbt
- worlds/raicom_workpieces_flat_test.wbt
