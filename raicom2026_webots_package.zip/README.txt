RAICOM2026 Webots package

Open worlds/raicom2026_arena.wbt in Webots.
All required PROTO, mesh, and PROTO preview icon files are included.
Generated on 2026-04-29.

Files:
- worlds/raicom2026_arena.wbt
- protos/Raicom2026Arena.proto
- protos/RaicomWorkpieceCircle.proto
- protos/RaicomWorkpieceClover.proto
- protos/RaicomWorkpieceParallelogram.proto
- protos/RaicomWorkpiecePentagon.proto
- protos/RaicomWorkpiecePlus.proto
- protos/RaicomWorkpieceRectangle.proto
- protos/RaicomWorkpieceSquare.proto
- protos/RaicomWorkpieceStar.proto
- protos/RaicomWorkpieceTriangle.proto
- protos/RaicomConvertedPlacementTray.proto
- protos/RaicomConvertedPickBox.proto
- meshes/converted/raicom_placement_tray_holed.obj
- meshes/converted/wuliaoxiaohe.stl
- protos/icons/Raicom2026Arena.png
- protos/icons/RaicomConvertedMesh.png
- protos/icons/RaicomConvertedPickBox.png
- protos/icons/RaicomConvertedPlacementTray.png
- protos/icons/RaicomWorkpieceCircle.png
- protos/icons/RaicomWorkpieceClover.png
- protos/icons/RaicomWorkpieceParallelogram.png
- protos/icons/RaicomWorkpiecePentagon.png
- protos/icons/RaicomWorkpiecePlus.png
- protos/icons/RaicomWorkpieceRectangle.png
- protos/icons/RaicomWorkpieceSquare.png
- protos/icons/RaicomWorkpieceStar.png
- protos/icons/RaicomWorkpieceTriangle.png
